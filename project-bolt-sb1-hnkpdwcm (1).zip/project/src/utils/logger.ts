export function logAttempt(attemptNumber: number): void {
    console.log(`\nAttempt #${attemptNumber}`);
}

export function logProxy(proxy: string): void {
    console.log(`Using proxy: ${proxy}`);
}

export function logError(error: any): void {
    if (error?.name === 'FaucetRateLimitError') {
        console.log('Rate limit reached. Switching to next proxy...');
    } else {
        console.error('Error occurred:', error.message || error);
    }
}