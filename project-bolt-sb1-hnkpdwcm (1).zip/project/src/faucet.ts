import { requestSuiFromFaucetV0, getFaucetHost } from '@mysten/sui.js/faucet';
import { getNextProxy } from './proxy';
import { logError } from './utils/logger';

export async function requestTestTokens(address: string): Promise<boolean> {
    try {
        console.log('Requesting test tokens...');
        
        const proxy = getNextProxy();
        if (!proxy) {
            console.log('No proxies available. Please add proxies to config.ts');
            return false;
        }

        const result = await requestSuiFromFaucetV0({
            host: getFaucetHost('testnet'),
            recipient: address,
            httpAgent: proxy
        });

        console.log('Tokens received successfully!');
        console.log('Transaction ID:', result.transferredGasObjects[0].id);
        return true;
        
    } catch (error: any) {
        logError(error);
        return false;
    }
}