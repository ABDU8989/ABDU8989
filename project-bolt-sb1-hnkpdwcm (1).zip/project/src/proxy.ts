import { HttpsProxyAgent } from 'https-proxy-agent';
import { CONFIG } from './config';

let currentProxyIndex = 0;
const usedProxies = new Set<number>();

export function getNextProxy(): HttpsProxyAgent | undefined {
    if (CONFIG.PROXIES.length === 0) return undefined;
    
    // إذا تم استخدام جميع البروكسيات، قم بإعادة تعيين القائمة
    if (usedProxies.size === CONFIG.PROXIES.length) {
        usedProxies.clear();
    }
    
    // ابحث عن بروكسي لم يتم استخدامه بعد
    while (usedProxies.has(currentProxyIndex)) {
        currentProxyIndex = (currentProxyIndex + 1) % CONFIG.PROXIES.length;
    }
    
    const proxy = CONFIG.PROXIES[currentProxyIndex];
    usedProxies.add(currentProxyIndex);
    currentProxyIndex = (currentProxyIndex + 1) % CONFIG.PROXIES.length;
    
    console.log(`Using proxy: ${proxy}`);
    return new HttpsProxyAgent(proxy);
}