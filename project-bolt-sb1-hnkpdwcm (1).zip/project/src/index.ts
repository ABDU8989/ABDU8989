import { requestTestTokens } from './faucet';
import { sleep } from './utils/delay';
import { logAttempt } from './utils/logger';
import { CONFIG } from './config';

async function startFaucetRequest() {
    let retryCount = 0;
    
    while (retryCount < CONFIG.MAX_RETRIES) {
        logAttempt(retryCount + 1);
        
        const success = await requestTestTokens(CONFIG.ADDRESS);
        if (success) {
            console.log('Request completed successfully!');
            break;
        }
        
        retryCount++;
        if (retryCount < CONFIG.MAX_RETRIES) {
            console.log(`Waiting ${CONFIG.DELAY_MS/1000} seconds before next attempt...`);
            await sleep(CONFIG.DELAY_MS);
        }
    }
    
    if (retryCount >= CONFIG.MAX_RETRIES) {
        console.log('Max retry attempts reached. Please try again later.');
    }
}

startFaucetRequest().catch(console.error);