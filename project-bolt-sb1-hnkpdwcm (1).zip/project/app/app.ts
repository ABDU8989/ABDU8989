import { Application } from '@nativescript/core'
import { MainPage } from './main-page'

Application.run({ create: () => new MainPage() })