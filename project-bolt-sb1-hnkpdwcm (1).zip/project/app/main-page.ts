import { EventData, Page } from '@nativescript/core'
import { MainViewModel } from './main-view-model'

export class MainPage extends Page {
    private viewModel: MainViewModel

    constructor() {
        super()
        this.viewModel = new MainViewModel()
    }

    onNavigatingTo(args: EventData) {
        super.onNavigatingTo(args)
        this.bindingContext = this.viewModel
    }
}