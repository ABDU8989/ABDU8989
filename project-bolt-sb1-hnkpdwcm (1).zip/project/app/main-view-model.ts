import { Observable } from '@nativescript/core'

export class MainViewModel extends Observable {
    private _message: string

    constructor() {
        super()
        this._message = 'مرحباً بك في تطبيقك الأول!'
        this.notifyPropertyChange('message', this._message)
    }

    get message(): string {
        return this._message
    }
}